<?php

birch_ns( 'birchschedule.model.cpt', function( $ns ) {

	} );
