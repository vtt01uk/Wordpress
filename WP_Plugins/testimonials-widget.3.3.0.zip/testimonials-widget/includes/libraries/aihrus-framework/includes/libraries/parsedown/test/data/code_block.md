    <?php

    $message = 'Hello World!';
    echo $message;

---

    > not a quote
    - not a list item
    [not a reference]: http://foo.com