AT&T has an ampersand in their name

this & that

4 < 5 and 6 > 5

<http://example.com/autolink?a=1&b=2>

[inline link](/script?a=1&b=2)

[reference link][1]

[1]: http://example.com/?a=1&b=2