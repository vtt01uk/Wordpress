<?php
/**
 * The template for displaying the footer.
 *
 * @package Great
 */

// Theme Footer Copyright Info-Text
echo great_copyright_infotext();great_wp_footer();wp_footer(); ?></body></html>
