<?php
	// Include all custom control
	require_once( get_template_directory() . '/inc/admin/class.customized-controls.php' );