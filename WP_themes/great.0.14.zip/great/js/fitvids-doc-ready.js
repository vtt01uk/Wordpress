// initialise plugins
jQuery(document).ready(function($){ 

	// Target your .container, .wrapper, .post, etc.
    jQuery("#main").fitVids();  
});