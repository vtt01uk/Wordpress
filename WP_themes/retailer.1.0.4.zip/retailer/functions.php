<?php
/**
 * retailer engine room
 *
 * @package retailer
 */

/**
 * Initialize all the things.
 */
require get_stylesheet_directory() . '/inc/init.php';