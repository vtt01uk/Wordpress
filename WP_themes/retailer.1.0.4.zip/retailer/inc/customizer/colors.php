<?php
/**
 * Retailer colors
 *
 * @package retailer
 */

/**
 * 
 * @return  string color
 */
function retailer_accent_color( $color ) {
	$color = '#d24032';
	return $color;
}
function retailer_white_color( $color ) {
	$color = '#ffffff';
	return $color;
}
function retailer_semi_dark_color( $color ) {
	$color = '#221E1D';
	return $color;
}
function retailer_alt_color( $color ) {
	$color = '#8a65c5';
	return $color;
}
function retailer_footerbg_color( $color ) {
	$color = '#4d5256';
	return $color;
}