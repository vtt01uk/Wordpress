<?php
/**
 * Retailer Theme Customizer functions
 *
 * @package retailer
 */

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 *
 * @since  1.0.0
 */

	function retailer_customize_preview_js() {
		wp_enqueue_script( 'retailer_customizer', get_stylesheet_directory_uri() . '/inc/customizer/js/customizer.min.js', array( 'customize-preview' ), '1.15', true );
	}


	/* social icons*/
	function retailer_social_icons()  { 

		$social_networks = array( array( 'name' => __('Facebook','retailer'), 'theme_mode' => 'retailer_facebook','icon' => 'fa-facebook' ),
		array( 'name' => __('Twitter','retailer'), 'theme_mode' => 'retailer_twitter','icon' => 'fa-twitter' ),
		array( 'name' => __('Google+','retailer'), 'theme_mode' => 'retailer_google','icon' => 'fa-google-plus' ),
		array( 'name' => __('Pinterest','retailer'), 'theme_mode' => 'retailer_pinterest','icon' => 'fa-pinterest' ),
		array( 'name' => __('Linkedin','retailer'), 'theme_mode' => 'retailer_linkedin','icon' => 'fa-linkedin' ),
		array( 'name' => __('Youtube','retailer'), 'theme_mode' => 'retailer_youtube','icon' => 'fa-youtube' ),
		array( 'name' => __('Tumblr','retailer'), 'theme_mode' => 'retailer_tumblr','icon' => 'fa-tumblr' ),
		array( 'name' => __('Instagram','retailer'), 'theme_mode' => 'retailer_instagram','icon' => 'fa-instagram' ),
		array( 'name' => __('Flickr','retailer'), 'theme_mode' => 'retailer_flickr','icon' => 'fa-flickr' ),
		array( 'name' => __('Vimeo','retailer'), 'theme_mode' => 'retailer_vimeo','icon' => 'fa-vimeo-square' ),
		array( 'name' => __('RSS','retailer'), 'theme_mode' => 'retailer_rss','icon' => 'fa-rss' )
		);


		for ($row = 0; $row < 11; $row++){
			if (get_theme_mod( $social_networks[$row]["theme_mode"])): ?>
				<a href="<?php echo esc_url( get_theme_mod($social_networks[$row]['theme_mode']) ); ?>" class="social-tw" title="<?php echo esc_url( get_theme_mod( $social_networks[$row]['theme_mode'] ) ); ?>">
				<span class="fa <?php echo $social_networks[$row]['icon']; ?>"></span> 
				</a>
			<?php endif;
		}
                      
	}

	function retailer_check_number( $value ) {
	    $value = (int) $value; // Force the value into integer type.
	    return ( 0 < $value ) ? $value : null;
	}