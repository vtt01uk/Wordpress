<?php
/**
 * Retailer customizer hooks
 *
 * @package retailer
 */

add_action( 'wp_enqueue_scripts', 									'retailer_add_customizer_css');

add_action( 'customize_preview_init', 								'retailer_customize_preview_js' );

add_action( 'customize_register', 									'retailer_customize_storefront_controls');

/**
 * Customizer default color tweaks
 */
add_filter( 'storefront_default_accent_color', 						'retailer_accent_color' );
add_filter( 'storefront_default_header_background_color', 			'retailer_white_color' );
add_filter( 'storefront_default_header_text_color', 				'retailer_accent_color' );
add_filter( 'storefront_default_header_link_color', 				'retailer_semi_dark_color' );
add_filter( 'storefront_default_button_background_color', 			'retailer_accent_color' );
add_filter( 'storefront_default_footer_background_color', 			'retailer_footerbg_color' );
add_filter( 'storefront_default_footer_heading_color', 				'retailer_white_color' );
add_filter( 'storefront_default_footer_text_color', 				'retailer_white_color' );
add_filter( 'storefront_default_footer_link_color', 				'retailer_white_color' );
add_filter( 'storefront_default_button_alt_background_color', 		'retailer_alt_color' );
add_filter( 'storefront_default_text_color', 						'retailer_semi_dark_color' );
