<?php
/**
 * Custom functions that act independently of the theme templates
 *
 * Eventually, some of the functionality here could be replaced by core features
 *
 * @package retailer
 */

/**
 * Check whether the Storefront Customizer settings ar enabled
 * @return boolean
 * @since  1.1.2
 */
function retailer_customizer_enabled() {
	return apply_filters( 'retailer_customizer_enabled', true );
}

/**
 * Query WooCommerce activation
 */
if ( ! function_exists( 'retailer_woocommerce_is_activated' ) ) {
	function retailer_woocommerce_is_activated() {
		return class_exists( 'woocommerce' ) ? true : false;
	}
}