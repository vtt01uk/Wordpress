<?php
/**
 * @package Shibui
 */
?>

<article id="post-<?php the_ID(); ?>" class="blog-grid one-forth-col">

	<?php if ( has_post_thumbnail() ) : ?>
        <div class="entry-image"><a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'landscape' ); ?></a></div>
    <?php endif; ?>

	<div class="content">
		<?php the_title( sprintf( '<h3 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' ); ?>
		<?php the_category(); ?>
	</div>

</article><!-- #post-## -->