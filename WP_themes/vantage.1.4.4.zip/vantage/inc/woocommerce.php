<?php
/**
 * Integrates this theme with WooCommerce.
 *
 * @package vantage
 * @since 1.0
 * @license GPL 2.0
 */
